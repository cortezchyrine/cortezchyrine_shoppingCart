<?php $__env->startSection('style'); ?>
    <style>
            .tableImg{
                margin: 3%;
                padding: 1%;
            }
            .image1{
                margin: 1%;
                border:solid;
                width: 200px;
                height: 300px;
            }
            .price{
                margin: 1%;
                border: solid;
                border-radius: 3px;
                background-color: white;
                padding: 1%; 
                width: 200px;   
            }

    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <nav class="navbar navbar-inverse navbar-static-top">
            <div class="container">
                <div class="navbar-header">

                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                    <!-- Branding Image -->
                     <a class="navbar-brand" href="<?php echo e(url('/')); ?>">Items</a>
					 <a class="navbar-brand" href="<?php echo e(url('/')); ?>">About Us</a>

                     </div>

                <div class="collapse navbar-collapse" id="app-navbar-collapse">
                    <!-- Left Side Of Navbar -->
                    <ul class="nav navbar-nav">
                        &nbsp;
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="nav navbar-nav navbar-right">
                        <!-- Authentication Links -->
                        <?php if(Auth::guest()): ?>
                            <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
                            <li><a href="<?php echo e(route('register')); ?>">Register</a></li>
                        <?php else: ?>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                </a>

                                <ul class="dropdown-menu" role="menu">
                                    <li>
                                        <a href="<?php echo e(route('logout')); ?>"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            Logout
                                        </a>

                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                        </form>
                                    </li>
                                    <li>
                                        <a href="/Profile">
                                           Edit Profile
                                        </a>

                                        </form>
                                    </li>

                                </ul>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>

          </nav>
               
                <div class="tableImg" >
        
                   <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

               <img class="image1" src="img/<?php echo e($product->img); ?>" name="img">
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="Adding/<?php echo e($product->id); ?>" name="id"><label class="price"> 
                Price:$<?php echo e($product->product_price); ?>.00</label>
                <input type="hidden" value="<?php echo e($product->product_price); ?>" name="price">
            </a>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

                 </div>
            
   

              
                

            
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>