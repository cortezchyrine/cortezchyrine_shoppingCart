<?php $__env->startSection('style'); ?>
    <style>
            .tableImg{
                margin: 3%;
                padding: 1%;
            }
            .image1{

                margin: 1%;
                border:solid;
                width: 200px;
                height: 300px;
            }
            .price{
                margin: 1%;
                border: solid;
                border-radius: 3px;
                background-color: white;
                padding: 1%; 
                width: 200px;   
            }

            .table{
                table-layout: auto;
                border: 1px solid black;
                border-collapse: collapse;
            }
   </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <nav class="navbar navbar-inverse navbar-static-top">
            <div class="container">
                <div class="navbar-header">

                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span claxss="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                    <!-- Branding Image -->
                     <a class="navbar-brand" href="<?php echo e(url('/')); ?>">Items</a>
					 <a class="navbar-brand" href="<?php echo e(url('/')); ?>">About Us</a>

                     </div>

                <div class="collapse navbar-collapse" id="app-navbar-collapse">
                    <!-- Left Side Of Navbar -->
                    <ul class="nav navbar-nav">
                        &nbsp;
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="nav navbar-nav navbar-right">
                        <!-- Authentication Links -->
                        <?php if(Auth::guest()): ?>
                            <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
                            <li><a href="<?php echo e(route('register')); ?>">Register</a></li>
                        <?php else: ?>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                </a>

                                <ul class="dropdown-menu" role="menu">
                                    <li>
                                        <a href="<?php echo e(route('logout')); ?>"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            Logout
                                        </a>

                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                        </form>
                                    </li>
                                    <li>
                                        <a href="/Profile">
                                           Edit Profile
                                        </a>
                                    <li>

                                        </form>
                                    </li>

                                </ul>
                            </li>
                             
                        <?php endif; ?>

      <a href="cart" class="btn btn-info btn-md">
          <span class="glyphicon glyphicon-shopping-cart"></span> Shopping Cart
        </a>

                    </ul>

                </div>


            </div>

          </nav>
               


         <form method="Post" action="Adding">
         <table>
                <div class="tableImg">
            
                   <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td>
                    <img class="image1" src="img/<?php echo e($product->img); ?>" name="img">
                       <a href="Adding\<?php echo e($product->id); ?>" name="product"><label class="price"> 
                            Price:$<?php echo e($product->product_price); ?>.00</label>  </a>
           </td>
           
<?php echo e(csrf_field()); ?>


                <input type="hidden" name="id" value="<?php echo e($product->id); ?>cc">
                <input type="hidden" name="img" value="<?php echo e($product->img); ?>">
                <input type="hidden" name="product_nameproduct_name" value="<?php echo e($product->product_name); ?>">
                <input type="hidden" name="product_price" value="<?php echo e($product->product_price); ?>">
                <input type="hidden" name="product_description" value="<?php echo e($product->product_description); ?>">            

 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>  
                 </div>
            
   </form>
                

            
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>