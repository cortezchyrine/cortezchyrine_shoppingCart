<!DOCTYPE html>
<html>
<head>
  <title></title>
  <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

</head>
<body>
<center>
      <div class="contaner">
<div class="pertlogo">                     

      <img class="logo" src="img/logo2.png">
</div> 
            <div class="logoContaner">

                    <div>
                      <img class="logo" src="img/checklogo.png">
                        <h1><span class="label label">Verify Your Account</span></h1>
                          
                    </div>
            </div>
             <div class="infoBack">       
                    <div class="infoContaner">
                            <div class="font"><label>Your Account Information</label></div>
                            <div class="font"><label>Account:</label></div>
                            <div class="font"><label>Verificatin link: </label></div>
              
                    </div> 

              <hr width="90%">
            
            <button type="button" class="btn btn-lg btn-warning ">Verify Your Account</button>
            </div>
            <div class="parContaner1">
            <p>If you are having any issues with you account, please don't hesitate to contact us by replying to this mail.<br>Thanks</p>
             </div>


            <div class="parContaner2">
              <p >You're receiving this email because you have an account in Huntr. If you are not sure why you're receiving this, please contact us.</p>
            </div>
         </center>

</div>
<style>
  body{
    background: black;
  }
  .contaner{
    border: solid;
    border-color: #d2e0e0;
    border-radius: 20px;
    border-width: 20px;
    color: gray;
    width: 40%;
      }
      .pertlogo{
        background-color: white;
      }

  .logoContaner{
    background-color: #0d0d0d;
    height: 10%;
  }
  .logo{
    margin-top: 2%;
    width: 30%;
    height: 10%;
  }

  .infoContaner{
    background-color: white;
    color: black;
  }
  .infoBack{
    padding: 10%;
    background-color: white;

  }
  .font{
    text-align: left;
    font-size: 15px;
  }
  .parContaner1{
    text-align: left;
    background-color: white;
    padding-top: 2%;
    padding-right: 8%;
    padding-left: 8%;
    padding-bottom: 8%;
    font-size: 120%;
    color: black;
  }
  .parContaner2{
    background-color: #f0f5f5; 
    padding: 8%;
    font-size: 80%;
      }
</style>

</body>
</html>