@extends('layouts.app')
@section('style')
    <style>
            .tableImg{
                margin: 3%;
                padding: 1%;
            }
            .image1{

                margin: 1%;
                border:solid;
                width: 200px;
                height: 300px;
            }
            .price{
                margin: 1%;
                border: solid;
                border-radius: 3px;
                background-color: white;
                padding: 1%; 
                width: 200px;   
            }

            .table{
                table-layout: auto;
                border: 1px solid black;
                border-collapse: collapse;
            }
   </style>
@endsection('style')
@section('content')
    <nav class="navbar navbar-inverse navbar-static-top">
            <div class="container">
                <div class="navbar-header">

                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span claxss="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                    <!-- Branding Image -->
					 <a class="navbar-brand" href="{{ url('/') }}">ClickClock</a>

                     </div>

                <div class="collapse navbar-collapse" id="app-navbar-collapse">
                    <!-- Left Side Of Navbar -->
                    <ul class="nav navbar-nav">
                        &nbsp;
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="nav navbar-nav navbar-right">
                        <!-- Authentication Links -->
                        @if (Auth::guest())
                            <li><a href="{{ route('login') }}">Login</a></li>
                            <li><a href="{{ route('register') }}">Register</a></li>
                        @else
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                    {{ Auth::user()->name }} <span class="caret"></span>
                                </a>

                                <ul class="dropdown-menu" role="menu">
                                    <li>
                                        <a href="{{ route('logout') }}"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            Logout
                                        </a>

                                        <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                            {{ csrf_field() }}
                                        </form>
                                    </li>
                                
                                        </form>
                                    </li>

                                </ul>
                            </li>
                             
                        @endif

      <a href="cart" class="btn btn-info btn-md">
          <span class="glyphicon glyphicon-shopping-cart"></span> Cart
        </a>

                    </ul>

                </div>


            </div>

          </nav>
               


         <form method="Post" action="Adding">
         <table>
                <div class="tableImg">
            
                   @foreach($products as $product)
                <td>
                   <center> <img class="image1" src="img/{{$product->img}}" name="img">
                       <a href="Adding\{{$product->id}}" name="product"><br><label class="description">{{$product->product_description}}</label><label class="price"> 
                            Price:${{$product->product_price}}.00</label>  </a> </center>
           </td>
           
{{csrf_field() }}

                <input type="hidden" name="id" value="{{$product->id}}cc">
                <input type="hidden" name="img" value="{{$product->img}}">
                <input type="hidden" name="product_nameproduct_name" value="{{$product->product_name}}">
                <input type="hidden" name="product_price" value="{{$product->product_price}}">
                <input type="hidden" name="product_description" value="{{$product->product_description}}">            

 
                        @endforeach
                </table>  
                 </div>
            
   </form>
                

            
@endsection