<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Product;
use Auth;
use App\Cart; 
use DB;
use App\carts_items;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
    
     $products = Product::all();
        
        return view('home', compact('products'));
    }

    public function profilePage(){
        return view('profile');
    }

public function addtocart(Request $request,$id){

    $user_id= auth::user()->id;
    $user_name= auth::user()->name;
    $cart_id= Cart::where('user_id',$user_id)-> value('id');
    $price= Product::where('id',$id)->value('product_price');
    $quantity = 1;
    $amount = $price*$quantity;
    $img= Product::where('id',$id)->value('img');


    DB::table('carts_items')->insert([
        'name'=>$user_name,
        'cart_id'=> $cart_id,
        'product_id'=>$id,
        'quantity'=>$quantity,
        'amount'=>$amount


    ]);

        return redirect('home');
 } 
public function show_cart(){

$carts_items= carts_items::all();
    
return view('cart',compact('carts_items'));

}


public function delete(Request $request,$id){

    DB::table('carts_items')->where('product_id',$id)->delete();

    return redirect('cart');

}
}
