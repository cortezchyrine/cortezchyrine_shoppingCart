<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class carts_items extends Model
{
    //
}
